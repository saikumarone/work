#!/bin/bash
# Usage: ./get_table_counts_remote.sh <ssh_user> <host> <db_name> <output_file>
# Example: ./get_table_counts_remote.sh ubuntu 10.0.0.12 mydb outputs/mydb_counts.txt
# Requires: passwordless SSH to <ssh_user>@<host>, and sudo access to user 'postgres' on the host.

set -e


SSH_USER=sadepollutp_gcp
HOST=gcpapp29lhc
DB_NAME=$1
OUTPUT_FILE=${HOST}_${DB_NAME}_Tablecounts.txt

# Ensure output directory exists
mkdir -p "$(dirname "$OUTPUT_FILE")"

# Header line: ============ <log file name without extension> ============
BASE_NAME=$(basename "$OUTPUT_FILE")
LOG_NAME="${BASE_NAME%.*}"
echo "=========== ${LOG_NAME} ===========" > "$OUTPUT_FILE"


# Fetch the table list by streaming SQL over SSH and sudo-ing to postgres
TABLES=$(
  ssh -o BatchMode=yes "${SSH_USER}@${HOST}" \
    "sudo -Hiu postgres psql -d \"$DB_NAME\" -At -f -" <<< "SELECT table_schema || '.' || table_name AS full_table_name
FROM information_schema.tables
WHERE table_type = 'BASE TABLE'
  AND table_catalog = '${DB_NAME}'
  AND table_schema NOT IN ('pg_catalog', 'information_schema', 'pg_toast', 'pglogical')
  AND (table_schema || '.' || table_name) NOT IN (
      'research.quote_snap',
      'market_builder_2.volatility_surface',
      'market_builder_2.bond_market_built_btt',
      'market_data.snap',
      'risk.riskbeta_reports',
      'research.daily',
      '_timescaledb_internal._compressed_hypertable_16',
      'ticks.trade',
      'research.quote_snap_credit',
      'research.credit_vol',
      'xccy.ubs_stir_analytics'
      )
ORDER BY table_schema, table_name;
"
)


if [ -z "$TABLES" ]; then
  echo "No tables found or connection failed." | tee -a "$OUTPUT_FILE"
  echo "==================================================" >> "$OUTPUT_FILE"
  exit 1
fi

# Loop through tables and get counts
# We quote identifiers to be safe (\"schema\".\"table\")
while IFS= read -r TBL; do
  # Skip empty lines defensively
   
  [ -z "$TBL" ] && continue
  COUNT=$(
    ssh -o BatchMode=yes "${SSH_USER}@${HOST}" \
      "sudo -Hiu postgres psql -d \"$DB_NAME\" -At -c \"SELECT COUNT(*) FROM $TBL;\"" </dev/null \
      || echo "ERROR"
  )
  if [[ "$COUNT" =~ ^[0-9]+$ ]]; then
    echo "${SCHEMA}.${TBL} | ${COUNT}" >> "$OUTPUT_FILE"
  else
    echo "${SCHEMA}.${TBL} | ERROR" >> "$OUTPUT_FILE"
  fi
done <<< "$TABLES"

echo "==================================================" >> "$OUTPUT_FILE"
echo "Done. Results saved to: $OUTPUT_FILE"
