import yaml
import os
import subprocess
import pandas as pd
from io import StringIO
import sys
import datetime
import logging
import validate_functions


## global vars used in functions

#v_base_dir = '/mnt/dump/pg-db-migration/dump'

# Configuration
#v_yaml_file = f'{v_base_dir}/config/migrate_db.yaml'

# Original SQL files location
#v_sql_dir = f'{v_base_dir}/validation/sql_scripts/'

# Directory to store modified SQL files.
#v_output_dir = f'{v_base_dir}/validation/modified_sql/' 
# working_dir = "/mnt/dump/dvt/venv/bin"  # working directory
#v_log_dir = f'{v_base_dir}/validation/logs'

# database to validate
#v_database = 'empty'
#v_source_host = 'empty'
#v_target_host = 'empty'
#v_schema_inclusion = 'empty'

#v_source_conn_string = 'empty'
#v_target_conn_string = 'empty' 

# validations:
validations_to_run = [
                {
                    'source_sql_filename': "objectsummary_source.sql",
                    'target_sql_filename': "objectsummary_target.sql",
                    'primary_key': "object_type",
                    'title': "\nObject Count Summary"
                    ,'screen': True
                },
                {
                    'source_sql_filename': "dbsize_source.sql",
                    'target_sql_filename': "dbsize_target.sql",
                    'primary_key': "db_name",
                    'title': "\nDatabase Status → Table 1"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "schema_source.sql",
                    'target_sql_filename': "schema_target.sql",
                    'primary_key': "schema_size",
                    'title': "\nSchema Status → Table 2"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "extension_source.sql",
                    'target_sql_filename': "extension_target.sql",
                    'primary_key': "extension_detail",
                    'title': "\nExtension Status → Table 3"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "views_source.sql",
                    'target_sql_filename': "views_target.sql",
                    'primary_key': "name",
                    'title': "\nView Status → Table 4"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "tablelist_source.sql",
                    'target_sql_filename': "tablelist_target.sql",
                    'primary_key': "table",
                    'title': "\nTable Status → Table 5"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "materializedviews_source.sql",
                    'target_sql_filename': "materializedviews_target.sql",
                    'primary_key': "view_name",
                    'title': "\nMaterialized View Status → Table 6"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "indexlist_source.sql",
                    'target_sql_filename': "indexlist_target.sql",
                    'primary_key': "index",
                    'title': "\nIndex Status → Table 7 \n[format:schemaname.tablename.indexname]\n"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "partition_source.sql",
                    'target_sql_filename': "partition_target.sql",
                    'primary_key': "partition",
                    'title': "\nPartition Status → Table 9 \n[format:parent_schema.parent.child_schema.child]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "triggerlist_source.sql",
                    'target_sql_filename': "triggerlist_target.sql",
                    'primary_key': "trigger",
                    'title': "\nTrigger Status → Table 10 \n[format: trigger_schema.table_name.trigger_name]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "sequences_source.sql",
                    'target_sql_filename': "sequences_target.sql",
                    'primary_key': "sequence",
                    'title': "\nSequence Status → Table 11 \n[format: sequence_schema.sequence_name.sequence_datatype]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "udflist_source.sql",
                    'target_sql_filename': "udflist_target.sql",
                    'primary_key': "function_name",
                    'title': "\nFunction Status → Table 12 \n[format: schema::functionname]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "pkeyconstraint_source.sql",
                    'target_sql_filename': "pkeyconstraint_target.sql",
                    'primary_key': "primary_key",
                    'title': "\nPrimary Key Status → Table 13 \n[format: schema.table.type.pkname]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "fkeyconstraint_source.sql",
                    'target_sql_filename': "fkeyconstraint_target.sql",
                    'primary_key': "foreign_key",
                    'title': "\nForeign Key Status → Table 14 \n[format: schema.table.type.fkname]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "uniqueconstraint_source.sql",
                    'target_sql_filename': "uniqueconstraint_target.sql",
                    'primary_key': "unique_cons",
                    'title': "\nUnique Constraint Status → Table 15 \n[format: schema.table.type.unique_cons_name]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "checkconstraint_source.sql",
                    'target_sql_filename': "checkconstraint_target.sql",
                    'primary_key': "check_cons",
                    'title': "\nCheck Constraint Status → Table 16 \n[format: schema.table.type.check_cons_name]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "columnorder_source.sql",
                    'target_sql_filename': "columnorder_target.sql",
                    'primary_key': "column",
                    'title': "\nColumn order → Table 17 \n[format: schema.table.position.column]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "invalid_cons_source.sql",
                    'target_sql_filename': "invalid_cons_target.sql",
                    'primary_key': "constraint",
                    'title': "\nInvalid Constraints → Table 18 \n[format: schema.table.constraint]"
                    ,'screen': False
                },
                {
                    'source_sql_filename': "invalid_idx_source.sql",
                    'target_sql_filename': "invalid_idx_target.sql",
                    'primary_key': "index",
                    'title': "\nInvalid Indexes → Table 19 \n[format: schema.table.index]"
                    ,'screen': False
                }
]


#######


def generate_schema_inclusion_clause_old(db_name):
    """
    Generates a SQL WHERE clause to *include* only the schemas listed for a specific database
    in the YAML configuration.

    Args:
        yaml_file (str): Path to the YAML configuration file.
        db_name (str): The name of the database for which to generate the inclusion clause.
        log (logging.Logger):  The logging.

    Returns:
        str: A SQL WHERE clause string, or None if no schemas are found for the database.
    """
    global v_schema_inclusion

    if v_schema_inclusion == 'empty': 
      try:
        with open(v_yaml_file, 'r') as f:
            config = yaml.safe_load(f)
      except FileNotFoundError:
        logging.error(f"Error: YAML file not found at {v_yaml_file}")
        return None
      except yaml.YAMLError as e:
        logging.error(f"Error parsing YAML: {e}")
        return None

      inclusion_schemas = []
      # will work only on the specified idatabase comparision, not all servers/databases
      for server in config.get('servers', []):
        if server['name'] == v_source_host:
          #print ("server match")
          for database in server.get('databases', []):
            if database['name'] == db_name:
                # print ("database match")
                if database['target'] == v_target_host:
                  #print ("all match")
                  inclusion_schemas = [schema['name'] for schema in database.get('schemas', [])]
                  break  # Found the database, no need to continue searching
          if inclusion_schemas:
            break  # Found schemas, stop searching servers
        if inclusion_schemas:
           break  # Found schemas, stop searching servers

      # adding common schemas
      for common in config.get('common_schemas', []):
      	inclusion_schemas.extend([common['name']])

      if not inclusion_schemas:
        logging.warning(f"Warning: No schemas found for database '{db_name}' in the YAML file.")
        return None  # Return None to indicate no schemas

      # Build the inclusion string.
      #inclusion_conditions = [f"'{schema}'" for schema in inclusion_schemas]
      #where_clause = "WHERE " + " OR ".join(inclusion_conditions)
      v_schema_inclusion = ','.join([f"'{schema}'" for schema in inclusion_schemas])
   
      logging.info(f" Schemas to validate: {v_schema_inclusion}")
      print(f" Schemas to validate: {v_schema_inclusion}")

    return v_schema_inclusion


def update_sql_file(sql_file, inclusion_clause, output_dir, db_name):
    """
    Updates a SQL file with the generated inclusion clause and saves it to a new directory.

    Args:
        sql_file (str): Path to the original SQL file.
        inclusion_clause (str): The SQL WHERE clause to add.
        output_dir (str): The directory where the modified SQL file should be saved.
        db_name (str): The name of the database.
        log (logging.Logger):  The logging.

    Returns:
        str: Path to the modified SQL file, or None on error.
    """
    try:
        with open(sql_file, 'r') as f:
            sql_content = f.read()
            # Check if a WHERE clause already exists.  If so, we need to AND it
            if ":include_schemas" in sql_content:
                # Simple, but not perfect, check.  Assumes only one WHERE.
                sql_content = sql_content.replace(":include_schemas", f"{inclusion_clause} ")
            #else:
            # no changes needed - we don't know if should add a where clause or not - using SQL as it was provided
            # sql_content += f"\n{inclusion_clause}"  # Append the WHERE clause

        # Create the output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)

        # Generate the new file name with the database name
        base_name = os.path.splitext(os.path.basename(sql_file))[0]
        new_file_name = f"{base_name}_{db_name}.sql"
        new_file_path = os.path.join(output_dir, new_file_name)

        # Write the modified content to the new file
        with open(new_file_path, 'w') as f:
            f.write(sql_content)

        logging.debug(f"Created modified SQL file: {new_file_path}")
        return new_file_path # Return the path to the modified SQL file

    except FileNotFoundError:
        logging.error(f"Error: SQL file not found at {sql_file}")
        return None  # Important: Return None on error
    except Exception as e:
        logging.error(f"Error updating SQL file: {e}")
        return None  # Important: Return None on error



def run_and_format_validation(source_connection, target_connection, source_sql_filename, target_sql_filename, primary_key, title, common_sql_path, modified_sql_dir, db_name, show_result):
    """Runs data-validation, formats the result, and prints output."""

    logging.info(f"Running validation: {title}")
    print(f"{title} ...") 

    source_sql_path = os.path.join(common_sql_path, source_sql_filename)

    # Generate and use modified SQL always - we can optimize this by avoiding re-generating script if exists
    #source_modified_sql_path = update_sql_file(source_sql_path, generate_schema_inclusion_clause(db_name), modified_sql_dir, db_name)
    source_modified_sql_path = update_sql_file(source_sql_path, validate_functions.v_schema_inclusion, modified_sql_dir, db_name)

    # using modified source file if target not defined
    if source_sql_filename != target_sql_filename:
       target_sql_path = os.path.join(common_sql_path, target_sql_filename)
       #target_modified_sql_path = update_sql_file(target_sql_path, generate_schema_inclusion_clause(db_name), modified_sql_dir, db_name)
       target_modified_sql_path = update_sql_file(target_sql_path, validate_functions.v_schema_inclusion, modified_sql_dir, db_name)
    else:
        target_modified_sql_path = source_modified_sql_path

    if source_modified_sql_path is None or target_modified_sql_path is None:
        logging.error(f"Skipping validation due to error generating modified SQL.  Check logfile")
        return False  # Exit the function if there's an error

    data_validation_command = f"{validate_functions.v_working_dir}/data-validation validate custom-query row -sc {source_connection} -tc {target_connection} -sqf=\"{source_modified_sql_path}\" -tqf=\"{target_modified_sql_path}\" --primary-keys=\"{primary_key}\" --concat='*' -fmt 'csv'"

    try:
        # failure will raise an error, as check=True
        logging.info(f"{data_validation_command}")
        result = subprocess.run(data_validation_command, shell=True, capture_output=True, text=True, check=True)
        df = pd.read_csv(StringIO(result.stdout))

        if df is not None and not df.empty:
            if 'validation_status' in df.columns:
                if 'fail' in df['validation_status'].values:
                    print("... Warning: Some rows failed to validate")
                    valida_res = False
                else:
                    print("... Validation Passed")
                    valida_res = True
            else:
                print("... Warning: 'validation_status' column not found in the output.")
                valida_res = True

            columns_to_extract = ['source_agg_value', 'target_agg_value', 'validation_status']
            filtered_df = df[columns_to_extract].astype(str)
            col_widths = {col: max(filtered_df[col].str.len().max(), len(col)) for col in filtered_df.columns}

            header = "  ".join(col.ljust(col_widths[col]) for col in filtered_df.columns)
            separator = "  ".join("-" * col_widths[col] for col in filtered_df.columns)

            logging.info(f"Validation Results:")
            logging.info(header)
            logging.info(separator)
            if show_result:
                print(f"Validation Results:")
                print(header)
                print(separator)

            for _, row in filtered_df.iterrows():
                logging.info("  ".join(row[col].ljust(col_widths[col]) for col in filtered_df.columns))
                if show_result:
                    print("  ".join(row[col].ljust(col_widths[col]) for col in filtered_df.columns))

            return valida_res
            #return False # Return False if there are differences

        elif result.returncode == 0:
            print("... Validation Passed")
            logging.info(f"Validation Passed for {title} for database {db_name}: No differences found.")
            logging.info(title)
            logging.info("       Source file                  Target file                                  REASON")
            logging.info(" ------------------------- -------------------------------    ---------------------------------------")
            logging.info(f"{source_sql_filename}           {target_sql_filename}       No Records Found in source and target")
            return True
        else:
            error_message = result.stderr.decode('utf-8')
            printf(f"## Error running validation: {error_message}") # Print to screen
            logging.error(f"Error running data-validation for {title} for database {db_name}: {error_message}")
            return None #stop

    except subprocess.CalledProcessError as e:
        error_stderr = str(e.stderr)
        error_message = str(e.stdout)
        print(f"Error running data-validation: {error_message}\n {error_stderr}")
        logging.info(f"Error running data-validation for {title} for database {db_name}: {error_message}\n {error_stderr}") # Add screen
        logging.info(title)
        logging.info("Source file               Target File              REASON")
        logging.info("-------------------- --------------------    --------------------")
        logging.info(f"{source_sql_filename}  {target_sql_filename} Validation Failed:{e}")
        return None #stop

    except Exception as e:
        error_stderr = str(e.stderr)
        error_message = str(e.stdout)
        logging.error(f"Exception occurred during validation for {title} for database {db_name}: {error_message}\n {error_stderr}")
        print(f"Exception occurred during validation: {error_message}\n {error_stderr}") # Add screen
        return None #stop


def run_object_comparision(source_connection, target_connection, common_sql_path, output_dir, log_file_name):
    """Main function to run multiple validations on a single database."""

    try:
        with open(validate_functions.v_yaml_file, 'r') as f:
            config = yaml.safe_load(f)
    except FileNotFoundError:
        logging.error(f"Error: YAML file not found at {validate_functions.v_yaml_file}")
        return False
    except yaml.YAMLError as e:
        logging.error(f"Error parsing YAML: {e}")
        return False

    all_validations_passed = True
    for server in config.get('servers', []):
      # print (f"comparing {server['name']} to {v_source_host}")
      if server['name'] == validate_functions.v_source_host:
        # print ("server match")
        host_name = server['name']
        host_output_dir = os.path.join(output_dir, host_name) #create host dirs
        os.makedirs(host_output_dir, exist_ok=True)

        for database in server.get('databases', []):
          if database['name'] == validate_functions.v_database:
            #print ("database match")
            db_name = database['name']

            #if database['target'] == v_target_host:
            logging.info(f"Running Validations for database: {db_name} on host {host_name}")
            print(f"Running validations for database: {db_name} on host {host_name}") #add screen output

            for validation in validations_to_run:
                source_sql_filename = validation['source_sql_filename']
                # using source SQL validation script if target SQL file does not exists 
                if os.path.exists(validate_functions.v_sql_dir + validation['target_sql_filename']):
                    target_sql_filename = validation['target_sql_filename']
                else:
                    target_sql_filename = source_sql_filename
                primary_key = validation['primary_key']
                title = validation['title']

                validation_result = run_and_format_validation(source_connection, target_connection, source_sql_filename, target_sql_filename, primary_key, title, common_sql_path, host_output_dir, db_name, validation['screen'])
                if validation_result is None: #stop if error
                    return False
                elif not validation_result:
                    all_validations_passed = False

    return all_validations_passed


def main():
    """
    Main function to run the schema comparison.
    """
    validate_functions.validate_params('validate_schema')

    # only validate tables configured to be migrated - this sets a global var used later
    validate_functions.generate_schema_inclusion_clause(validate_functions.v_database)

    if run_object_comparision(validate_functions.v_source_conn_string, validate_functions.v_target_conn_string, validate_functions.v_sql_dir, validate_functions.v_output_dir, validate_functions.v_log_file_name):
        msg="###   All schema comparisons successful.  Detailed log file -> "+validate_functions.v_log_file_name+" ### "
        logging.info(msg)
        print(msg)
    else:
        msg="### Schema comparisons failed.  See log for details -> "+validate_functions.v_log_file_name+"."
        logging.info(msg)
        print(msg)
        sys.exit(1) #stop on error

    return


def main_old():
    """
    Main function to run the schema comparison.
    """
    # Ensure the script's directory is in the path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)

    if len(sys.argv) < 4:
        print("Usage: python __file__ <source_host> <database> <target_host> [--debug]")
        sys.exit(1)

    global v_source_host
    global v_database
    global v_target_host
    v_source_host = sys.argv[1].split('.')[0]
    v_database = sys.argv[2]
    v_target_host = sys.argv[3]

    print(f"parameters: {v_source_host} {v_database} {v_target_host}")

    global v_source_conn_string
    global v_target_conn_string
    v_source_conn_string = "psql_prod_"+v_database+"_source"
    v_target_conn_string = "psql_prod_"+v_database+"_target"

    print(f"connection strings: source = {v_source_conn_string} target = {v_target_conn_string}")

    # Set up logging
    #log_dir = os.path.join(script_dir, 'logs')  # Create a logs directory
    os.makedirs(v_log_dir, exist_ok=True)
    now = datetime.datetime.now()

    log_file_name = os.path.join(v_log_dir, f"validation_{v_database}_{now.strftime('%Y%m%d_%H%M%S')}.log") # log file name
    if "--debug" in sys.argv:
        logging_level = logging.DEBUG
    else:
        logging_level = logging.INFO
    
    print(f"Detailed log -> {log_file_name}")

    logging.basicConfig(filename=log_file_name, level=logging_level, format='%(asctime)s - %(levelname)s - %(message)s')
    #logging.= logging.getLogger()
    #file_handler = logging.FileHandler(log_file_name)
    #formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    #file_handler.setFormatter(formatter)
    #logging.addHandler(file_handler)

    if run_object_comparision(v_source_conn_string, v_target_conn_string, v_sql_dir, v_output_dir, log_file_name):
        msg="###   All schema comparisons successful.  Detailed log file -> "+log_file_name+" ### "
        logging.info(msg)
        print(msg)
    else:
        msg="### Schema comparisons failed.  See log for details -> "+log_file_name+"."
        logging.info(msg)
        print(msg)
        sys.exit(1) #stop on error


if __name__ == "__main__":
    main()

