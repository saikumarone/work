import os
import re
import subprocess
import logging
import pandas as pd
import datetime
from io import StringIO
import argparse
import textwrap
from sqlalchemy.dialects.postgresql import TSTZRANGE
import sys

# Pythian functions to manage config
import validate_functions

# Import the DataValidator class from valida_hash.py
from valida_hash import DataValidator

import pgpasslib


# Set up logging
#logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")



def getPass(server, db, user):
  try:
    password = pgpasslib.getpass(server, 5432, db, user)
    if not password:
        raise ValueError('Password not found in .pgpass')
    #print(f"Password: {password}")
    return password

  except pgpasslib.FileNotFound:
    logging.error("Error: .pgpass file not found.")
  except pgpasslib.InvalidEntry:
    logging.error("Error: Invalid entry in .pgpass file.")
  except ValueError as e:
    logging.error(f"Error: {e}")


def process_tables(data_validation_path, source_config, target_config, output_path, log_filename, sample_size=500, debug_mode=False):
    """Fetches tables, processes each table, and saves results sequentially."""

    global process_start_time

    abs_data_validation_path = os.path.abspath(data_validation_path)
    os.chdir(abs_data_validation_path)

    # Output file name
    current_time = datetime.datetime.now().strftime("%d%m%Y%H%M%S")
    file_name = f"validate_report_{validate_functions.v_database}_{current_time}.txt"
    output_file_name = f"{output_path}/{file_name}"

    logging.info(f"# Real log file -> f{output_file_name}")

    # Initialize DataValidator
    hash_validator = DataValidator(source_config, target_config, validate_functions.v_schema_inclusion, sample_size, debug=debug_mode)

    # Open output file
    with open(output_file_name, 'w') as output_file:
        output_file.write("\nMigration Validation Status:\n")
        output_file.write(f"{'Table Name':<35} {'Count_Source':<15} {'Count_Target':<15} {'Count_Status':<10} {'Hash_Status':<25} {'Method':<10} {'start_time':<20} {'end_time':<20}\n")
        output_file.write(f"{'-'*35} {'-'*15} {'-'*15} {'-'*10} {'-'*25} {'-'*10} {'-'*20} {'-'*20}\n")
        print_tables = []

        # Establish database connections once
        source_conn = hash_validator._connect(source_config)
        target_conn = hash_validator._connect(target_config)

        if not source_conn or not target_conn:
            logging.error("Failed to establish database connections. Exiting.")
            return

        source_tables = hash_validator._get_tables(source_conn, validate_functions.v_schema_inclusion)
        # Sorted by table size, smallest first
        tables = sorted(source_tables, key=lambda x: x[2])
        # source_table_set = set(source_tables)
        # tables = sorted(list(source_table_set))
        logging.info(f"Tables to validate: {len(tables)}   Sample size {sample_size} rows")
        final_exit_status = 0    #  Sucess in all validations will return 0, else return 1

        for schema, table, table_size in tables:
            table_failed = True  # Flag to track if the table is fully failed
            table_size = int(table_size)
            # logging.info(f"Table {schema}.{table} - {table_size} bytes")

            count_status = "N/A"
            hash_status = "N/A"
            validation_method = "N/A"
            start_time_str = ""
            end_time_str = ""

            hash_duration = 0
            # Perform hash validation if table size exceeds a threshold (e.g., 10 GB)
            # validate less rows in large tables, as it takes long to select on source
            # if table_size > 1 * 1024 * 1024 * 1024 or 'success' in count_status.lower():
            #   hash_validator.sample_size=100
            #else:
            #   hash_validator.sample_size=500

            logging.info(f"{schema}.{table} - ({table_size} bytes)")

            # hash valiadation always:
            #if True:   
            # excluding 100Gb table that this hash times out - moved this into the hash function to log messages
            if True:   # not (schema == "pro_product" and table == "participation_state"):   
                msg = f" sample={hash_validator.sample_size}" if (hash_validator.sample_size!=sample_size) else ""
                logging.info(f".. Hash {msg}")
                hash_result, hash_duration = hash_validator.validate_table(source_conn, target_conn, schema, table, table_size)
                hash_status = hash_result
                if 'No Primary Key' in hash_status or 'Skipped' in hash_status:
                    print_tables.append(f"{schema}.{table}: Hash not validated, {hash_status}")
                    table_failed = False        # cannot abort the validation for this - trusting count
                elif 'Mismatch' not in hash_status:
                    table_failed = False
                else:
                    print_tables.append(f"{schema}.{table}: {hash_status}")
                msg = f"      {hash_status}   elapsed={hash_duration:.2f}"
                #print(msg)
                logging.info(msg)
            else:
                logging.info(f"... {schema}.{table} - Skipping Hash because it hangs now ({table_size} bytes)")

            # doing count for smaller tables only
            if table_size < 10 * 1024 * 1024 * 1024:    # or 'success' in count_status.lower():
                logging.info(f".. Count")
                start_time = datetime.datetime.now(datetime.timezone.utc)
                count_source, count_target = hash_validator.count_table(source_conn, target_conn, schema, table)
                end_time = datetime.datetime.now(datetime.timezone.utc)
                elap = (end_time - start_time).total_seconds()

                if count_source is None or count_target is None:
                    count_status = 'error'
                elif count_source == count_target:
                    count_status = 'OK'
                    # this will overwrite hash validation failures - those are added to the log table above
                    table_failed = False
                else:
                    #count_status = f'Mismatch ({count_source}/{count_target})'
                    count_status = f'Mismatch'
                msg = f"      {count_status}    source={count_source} target={count_target}  elapsed={elap:.2f}"
                logging.info(msg)

#            output_file.write(f"{f'{schema}.{table}':<35} {df_count['source_agg_value'][0]:<15 if df_count is not None and not df_count.empty else 'N/A':<15} {df_count['target_agg_value'][0]:<15 if df_count is not None and not df_count.empty else 'N/A':<15} {count_status:<10} {hash_status:<25} {validation_method:<10} {start_time_str:<20} {end_time_str:<20}\n")

            if table_failed:
               # and 'Skipped' not in hash_status and 'No Primary Key' not in hash_status:
               print_tables.append(f"{schema}.{table}: Count Status - {count_status}, Hash Status - {hash_status}")
               final_exit_status = 1

        # Close database connections
        source_conn.close()
        target_conn.close()

        if print_tables:
            output_file.write("\nValidation Failed for these tables:\n")
            output_file.write("source_table_name                                     status\n")
            output_file.write("------------------------------------ ------------------------------------\n")
            output_file.writelines([f"{table}\n" for table in print_tables])
        else:
            output_file.write("\nAll tables validated successfully.\n\n")
            logging.info(f"{validate_functions.v_database} - All tables validated successfully")

    # Writing all output to the screen
    #with open(output_file_name, 'r') as f:
    #    print(f.read())

    end_time = datetime.datetime.now(datetime.timezone.utc)
    elap = (end_time - process_start_time).total_seconds()

    #print(f"\nValidation completed !!  Elapsed: {elap} secs.    Log -> {output_file_name}")
    logging.info(f"\nValidation completed !!  {validate_functions.v_database}   Elapsed: {elap:.2f} secs.   Log -> {output_file_name}")

    # return failed status if any table validation failed
    #sys.exit(final_exit_status)
    # for cutover validations we cannot cancel execution of next scripts
    sys.exit(0)


if __name__ == "__main__":
    global process_start_time
    process_start_time = datetime.datetime.now(datetime.timezone.utc)

	
    # Parse arguments
    validate_functions.validate_params('validate_counts')

    # source and target database connection details
    _host=f"{validate_functions.v_source_host}.prod.porch.com"
    _userS='nelsoncalero'
    _userT='app_replica'

    source_config = {
        'host': _host,
        'port': 5432,
        'database': validate_functions.v_database,
        'user': _userS,
        'password': getPass(_host, validate_functions.v_database, _userS)
    }

    _host=validate_functions.v_target_IP
    # if not passed, using db-pro-1
    if _host == 'empty':
        logging.error("Need to specify the target IP address as fourth paramter")
        sys.exit(1)
        #_host='10.180.0.14'

    else:
      target_config = {
        'host': _host,
        'port': 5432,
        'database': validate_functions.v_database,
        'user': _userT,
        'password': getPass(_host, validate_functions.v_database, _userT)
      }

      # Optional: Specify schemas to exclude
      #excluded_schemas = ['pglogical', 'audit', 'temp_work', 'common', 'db_build', 'pg_catalog', 'information_schema', 'pg_toast', 'pg_temp_1', 'pg_xlog']

      # Optional: Specify the number of primary keys to sample per table
      sample_size = 500

      # Enable debug mode to see executed SQL queries
      debug_mode = False

      # only validate tables configured to be migrated - this sets a global var used later
      validate_functions.generate_schema_inclusion_clause(validate_functions.v_database)

      # process_tables(validate_functions.v_working_dir, validate_functions.v_source_conn_string, validate_functions.v_target_conn_string, validate_functions.v_log_dir, validate_functions.v_log_file_name)

      process_tables(validate_functions.v_working_dir, source_config, target_config, validate_functions.v_log_dir, validate_functions.v_log_file_name, sample_size=500, debug_mode=False)

      #  validator = DataValidator(source_config, target_config, excluded_schemas, sample_size, debug=debug_mode)
      # validator.run_validation()

	
