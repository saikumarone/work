import yaml
import os
import subprocess
import pandas as pd
from io import StringIO
import sys
import datetime
import logging


## global vars used in functions

v_base_dir = '/mnt/dump/pg-db-migration/dump' 

# Configuration
v_yaml_file = f'{v_base_dir}/config/migrate_db.yaml'  

# Original SQL files location
v_sql_dir = f'{v_base_dir}/validation/sql_scripts/'

# Directory to store modified SQL files.
v_output_dir = f'{v_base_dir}/validation/modified_sql/' # Added output dir

v_log_dir = f'{v_base_dir}/validation/logs'
v_log_file_name = 'empty' 

v_working_dir = "/mnt/dump/dvt/venv/bin"  # working directory

# database to validate
v_database = 'empty'
v_source_host = 'empty'
v_target_host = 'empty'
v_target_IP = 'empty'
v_schema_inclusion = 'empty'

v_source_conn_string = 'empty'
v_target_conn_string = 'empty' 


#######


def generate_schema_inclusion_clause(db_name):
    """
    Generates a SQL WHERE clause to *include* only the schemas listed for a specific database
    in the YAML configuration.

    Args:
        yaml_file (str): Path to the YAML configuration file.
        db_name (str): The name of the database for which to generate the inclusion clause.
        log (logging.Logger):  The logging.

    Returns:
        str: A SQL WHERE clause string, or None if no schemas are found for the database.
    """
    global v_schema_inclusion

    if v_schema_inclusion == 'empty': 
      try:
        with open(v_yaml_file, 'r') as f:
            config = yaml.safe_load(f)
      except FileNotFoundError:
        logging.error(f"Error: YAML file not found at {yaml_file}")
        return None
      except yaml.YAMLError as e:
        logging.error(f"Error parsing YAML: {e}")
        return None

      inclusion_schemas = []
      # will work only on the specified idatabase comparision, not all servers/databases
      for server in config.get('servers', []):
        if server['name'] == v_source_host:
          #print ("server match")
          for database in server.get('databases', []):
            if database['name'] == db_name:
                # print ("database match")
                if database['target'] == v_target_host:
                  #print ("all match")
                  inclusion_schemas = [schema['name'] for schema in database.get('schemas', [])]
                  # log and/or base schemas?
                  for schema in database['schemas']:
                      if schema.get('source'):
                         inclusion_schemas.append(f"{schema['name']}_source")
                         if schema.get('log'):
                            inclusion_schemas.append(f"{schema['name']}_source_log")
                      if schema.get('log'):
                         inclusion_schemas.append(f"{schema['name']}_log")
                  break  # Found the database, no need to continue searching
          if inclusion_schemas:
            break  # Found schemas, stop searching servers
        if inclusion_schemas:
           break  # Found schemas, stop searching servers

      # adding common schemas
      # we don't copy data for public schema - so we will hardcode here to skip it, and schema_validation will add it 
      for common in config.get('common_schemas', []):
      	if common['name'] != 'public':
      		inclusion_schemas.extend([common['name']])
      #inclusion_schemas.extend('common')

      if not inclusion_schemas:
        logging.warning(f"Warning: No schemas found for database '{db_name}' in the YAML file.")
        return None  # Return None to indicate no schemas

      # Build the inclusion string.
      #inclusion_conditions = [f"'{schema}'" for schema in inclusion_schemas]
      #where_clause = "WHERE " + " OR ".join(inclusion_conditions)
      v_schema_inclusion = ','.join([f"'{schema}'" for schema in inclusion_schemas])
   
      logging.info(f" Schemas to validate: {v_schema_inclusion}")
      print(f" Schemas to validate: {v_schema_inclusion}")

    return v_schema_inclusion


def validate_params(valname):
    """
    Main function to run the schema comparison.
    """
    # Ensure the script's directory is in the path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)

    if len(sys.argv) < 4:
        print(f"Usage: python {valname} <source_host> <database> <target_host> [target_name] [--debug]")
        sys.exit(1)

    global v_source_host
    global v_database
    global v_target_host
    v_source_host = sys.argv[1].split('.')[0]
    v_database = sys.argv[2]
    v_target_host = sys.argv[3]

    global v_target_IP
    if len(sys.argv) > 4:
       v_target_IP = sys.argv[4]

    # print(f"parameters: {v_source_host} {v_database} {v_target_host}")

    global v_source_conn_string
    global v_target_conn_string
    v_source_conn_string = "psql_prod_"+v_database+"_source"
    v_target_conn_string = "psql_prod_"+v_database+"_target"

    print(f"connection strings: source = {v_source_conn_string} target = {v_target_conn_string}")

    # Set up logging
    os.makedirs(v_log_dir, exist_ok=True)
    now = datetime.datetime.now()

    global v_log_file_name
    v_log_file_name = os.path.join(v_log_dir, f"{valname}_{v_database}_{now.strftime('%Y%m%d_%H%M%S')}.log") # log file name
    if "--debug" in sys.argv:
        logging_level = logging.DEBUG
    else:
        logging_level = logging.INFO

    print(f"Detailed log -> {v_log_file_name}")

    # this sends all log to a file - nothing to screen
    logging.basicConfig(filename=v_log_file_name, level=logging_level, format='%(asctime)s - %(levelname)s - %(message)s')
    #logging.= logging.getLogger()
    #file_handler = logging.FileHandler(log_file_name)
    #formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    #file_handler.setFormatter(formatter)
    #logging.addHandler(file_handler)


