select schemaname||'.'||matviewname as view_name
       --matviewowner as owner,
       --ispopulated as is_populated
from pg_matviews
where schemaname in (:include_schemas)
order by 1;
