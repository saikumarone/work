SELECT n.nspname||'.'||p.proname AS function_name
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
LEFT JOIN pg_depend d ON d.objid = p.oid AND d.deptype = 'e'
WHERE p.prokind = 'f'  -- regular user-defined functions
  AND d.objid IS NULL  -- not from extensions
  AND n.nspname IN (:include_schemas)
ORDER BY 1;
