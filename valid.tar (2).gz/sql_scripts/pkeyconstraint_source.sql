WITH relevant_schemas AS (
    SELECT n.oid AS namespace_oid, n.nspname
    FROM pg_namespace n
    WHERE nspname IN (:include_schemas)
)
SELECT s.nspname||'.'||rel.relname||'.'||con.contype||'.'||con.conname as primary_key
FROM pg_constraint con
 INNER JOIN relevant_schemas s ON s.namespace_oid = con.connamespace
 INNER JOIN pg_catalog.pg_class rel ON rel.oid = con.conrelid
WHERE con.contype='p'
order by 1;
