SELECT n.nspname||'.'||p.proname AS function_name
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
LEFT JOIN pg_depend d ON d.objid = p.oid AND d.deptype = 'e'
WHERE p.proisagg = false            -- not aggregate for V9.6
--WHERE p.prokind = 'f'               -- normal functions for V14
  AND p.proiswindow = false         -- not window function for V9.6
  AND d.objid IS NULL               -- not from extension
  AND n.nspname IN (:include_schemas)
ORDER BY 1;

