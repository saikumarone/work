SELECT trigger_schema||'.'||event_object_table||'.'||trigger_name  as trigger
FROM information_schema.triggers 
WHERE trigger_schema IN (:include_schemas)
GROUP BY trigger_schema, event_object_table, trigger_name 
ORDER BY 1;
