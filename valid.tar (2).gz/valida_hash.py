import psycopg2
import psycopg2.extensions
import hashlib
import json
import logging
import random
from datetime import datetime, date, time as dt_time, timedelta
from psycopg2.extras import DateTimeTZRange  # Import the specific type
from psycopg2.extras import DateRange  # Import the specific type
from psycopg2.extras import NumericRange  
from decimal import Decimal
import time
import base64
import threading

# Configure logging to screen
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class DataValidator:
    def __init__(self, source_config, target_config, excluded_schemas=None, sample_size=1000, debug=False):
        """
        Initializes the DataValidator with database configurations and settings.

        Args:
            source_config (dict): Dictionary containing connection details for the source PostgreSQL database.
                                   Required keys: 'host', 'port', 'database', 'user', 'password'.
            target_config (dict): Dictionary containing connection details for the target PostgreSQL database.
                                   Required keys: 'host', 'port', 'database', 'user', 'password'.
            excluded_schemas (list, optional): List of schema names to exclude from validation. Defaults to None.
            sample_size (int, optional): Number of primary keys to sample for validation per table. Defaults to 1000.
            debug (bool, optional): Flag to enable debug mode, printing executed SQL queries. Defaults to False.
        """
        self.source_config = source_config
        self.target_config = target_config
        self.excluded_schemas = excluded_schemas if excluded_schemas else ['pg_catalog', 'information_schema', 'pg_toast', 'pg_temp_1', 'pg_xlog', 'pglogical']
        self.sample_size = sample_size
        self.debug = debug

    def _execute_sql(self, cursor, sql, conn, params=None):
        """Executes SQL and optionally prints it if debug mode is enabled."""
        #if self.debug:
        #logging.info(f"Executing SQL: {cursor.mogrify(sql, params).decode('utf-8') if params else sql}")
        try: 
            cursor.execute(sql, params)
        except psycopg2.Error as e:
            # Crucially, roll back the transaction on the connection
            # associated with this cursor.
            logging.error(f"DATABASE ERROR during SQL execution: {e}")
            #print(f"SQL: {sql}")
            #if params:
            #    print(f"Params: {params}")
            
            # Check if conn is not None and has a rollback method
            if conn:
                try:
                    conn.rollback()
                    #print("Transaction rolled back due to error.")
                except Exception as rb_e:
                    logging.error(f"Error during rollback after SQL failed: {rb_e}")
            raise # Re-raise the exception so calling functions know it failed


    def _connect(self, config):
        """Establishes a connection to the PostgreSQL database."""
        try:
            conn = psycopg2.connect(**config)

            # Force DATE, TIMESTAMP, TIMESTAMPTZ to return as strings (not datetime objects)
            DATE_OID = 1082
            TIMESTAMP_OID = 1114
            TIMESTAMPTZ_OID = 1184

            def cast_date_to_str(value, cursor):
                return value  # Return raw string

            psycopg2.extensions.register_type(
                psycopg2.extensions.new_type((DATE_OID,), "DATE", cast_date_to_str),
                conn
            )
            psycopg2.extensions.register_type(
                psycopg2.extensions.new_type((TIMESTAMP_OID,), "TIMESTAMP", cast_date_to_str),
                conn
            )
            psycopg2.extensions.register_type(
                psycopg2.extensions.new_type((TIMESTAMPTZ_OID,), "TIMESTAMPTZ", cast_date_to_str),
                conn
            )

            return conn
        except psycopg2.Error as e:
            logging.error(f"Error connecting to database: {e}")
            return None


    def _get_table_rows_est(self, conn, schema, table):
        """Retrieves a list of tables from the database, excluding specified schemas."""

        cursor = conn.cursor()
        sql = f"""
    SELECT reltuples::BIGINT as rows
    FROM pg_class
    WHERE relname = '{table}'
      AND relnamespace = (SELECT oid FROM pg_namespace WHERE nspname = '{schema}')
        """
        self._execute_sql(cursor, sql, conn)
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else 0


    def _get_tables(self, conn, schema_inclusion):
        """Retrieves a list of tables from the database, excluding specified schemas."""
        cursor = conn.cursor()
        sql = f"""
            SELECT table_schema, table_name, pg_total_relation_size(CONCAT(table_schema, '.', table_name)) AS table_size
            FROM information_schema.tables
            WHERE table_type = 'BASE TABLE'
            AND table_schema IN ({schema_inclusion})
        """
        self._execute_sql(cursor, sql, conn)
        #(tuple(self.excluded_schemas),))
        tables = [(row[0], row[1], row[2]) for row in cursor.fetchall()]
        #print(f" ## Tables to validate: {len(tables)}")
        cursor.close()
        return tables

    def _get_primary_key_columns(self, conn, schema, table):
        """Retrieves the names of the primary key columns for a given table."""
        cursor = conn.cursor()
        sql = """
            SELECT kcu.column_name
            FROM information_schema.table_constraints AS tc
            JOIN information_schema.key_column_usage AS kcu
                 ON tc.constraint_name = kcu.constraint_name
                 AND tc.table_schema = kcu.table_schema
                 AND tc.table_name = kcu.table_name
            WHERE tc.constraint_type = 'PRIMARY KEY'
              AND tc.table_schema = %s
              AND tc.table_name = %s
            ORDER BY kcu.ordinal_position;
        """
        try:
          self._execute_sql(cursor, sql, conn, (schema, table))
          pk_columns = [row[0] for row in cursor.fetchall()]
          cursor.close()
          return pk_columns
        except Exception as e:
          print(f"ERROR during validate_table for {schema}.{table}: {e}")
          #import traceback
          #traceback.print_exc()
          return []
        finally:
          # Ensure cursors are closed
          if cursor:
             cursor.close()


    def _get_random_primary_keys(self, conn, schema, table, pk_columns, sample_perc):
        """Retrieves a sample of random primary keys from a table without using COUNT(*)."""
        if not pk_columns:
            return []

        cursor = conn.cursor()
        pk_column_str = ", ".join(pk_columns)
        where_clause = " AND ".join([f"{col} IS NOT NULL" for col in pk_columns])
        sql = f"""
                SELECT {pk_column_str}
                FROM {schema}.{table} TABLESAMPLE SYSTEM(%s) 
                WHERE {where_clause}
                LIMIT %s;
        """
        #        ORDER BY RANDOM()   # changed by TABLESAMPLE

        # big table never ending select
        if False:   # (schema == "pro_product" and table == "participation_state"):
           logging.info(f"....   getting random PK using {sql}")
           fetch_limit = 100     # only 100 rows
        else:
           fetch_limit = max(2 * self.sample_size, 1000)

        #logging.info(f"....   getting random PKs")
        self._execute_sql(cursor, sql, conn, (sample_perc,fetch_limit,))
        if len(pk_columns) == 1:
            all_pks = [row[0] for row in cursor.fetchall()]
        else:
            all_pks = [tuple(row) for row in cursor.fetchall()]

        cursor.close()
        return random.sample(all_pks, min(len(all_pks), self.sample_size))


    def _process_value(self, col, value):
        #valtype = type(value)
        #logging.info(f"######### col {col} type {valtype}")
        if isinstance(value, (datetime, time.struct_time, dt_time)):
            return value.isoformat()
        elif isinstance(value, (DateTimeTZRange, Decimal, NumericRange, date, timedelta, list, DateRange)):
            #logging.info(f"######### col {col} found group 2")
            return str(value)
        elif isinstance(value, memoryview):
            return base64.b64encode(value.tobytes()).decode('utf-8')
        else:
            return value


    def _fetch_data_by_pk(self, key, conn, schema, table, pk_columns, pk_values, all_results):
        """Fetches data for a given set of primary key values and handles datetime and DateTimeTZRange objects."""
        if not pk_columns or not pk_values:
            return []

        cursor = conn.cursor()
        cursor.execute("SET extra_float_digits=0;")

        pk_conditions = []
        if len(pk_columns) == 1:
            pk_conditions.append(f"{pk_columns[0]} IN %s")
        else:
            placeholders = "(" + ", ".join(["%s"] * len(pk_columns)) + ")"
            pk_conditions.append(f"({', '.join(pk_columns)}) IN %s")

        where_clause = " AND ".join(pk_conditions)
        sql = f"""
            SELECT *
            FROM {schema}.{table}
            WHERE {where_clause};
        """
        #logging.info(f"....  Fetching data by PK")

        # big table never ending select
        #if (schema == "pro_product" and table == "participation_state"):
        #   logging.info(f"....  Fetching data by PK using {sql}")
        try:
          self._execute_sql(cursor, sql, conn, (tuple(pk_values),))
          rows = cursor.fetchall()
          columns = [desc[0] for desc in cursor.description]
          cursor.close()
          # Convert datetime and DateTimeTZRange objects to strings
          all_results.append({"id": key, "data":[
            {
                #col: (value.isoformat() if isinstance(value, (datetime, time.struct_time, dt_time))
                #      else str(value) if isinstance(value, (DateTimeTZRange, Decimal, NumericRange, date, timedelta))
                #      else base64.b64encode(value.tobytes()).decode('utf-8') if isinstance(value, memoryview)
                #      else value)
                col: self._process_value(col, value)
                     for col, value in zip(columns, row)
            }
            for row in rows
          ]})

        except psycopg2.errors.UndefinedTable as e:
          logging.error(f"Table not found during data fetch in _fetch_data_by_pk")
          #logging.error(f"Table not found during data fetch in _fetch_data_by_pk: {e}")
          # Log the error, maybe mark this table as failed, and return an empty list/dict
          all_results.append({"id": key, "data":[]})
          if cursor:
             cursor.close()

        except psycopg2.Error as e: # Catch other psycopg2 errors
          logging.error(f"Database error in _fetch_data_by_pk")
          #logging.error(f"Database error in _fetch_data_by_pk: {e}")
          # Log the error and return empty data
          all_results.append({"id": key, "data":[]})
          if cursor:
             cursor.close()

        except Exception as e: # Catch any other unexpected errors
          logging.error(f"An unexpected error occurred in _fetch_data_by_pk: {e}")
          # Log and return empty data
          all_results.append({"id": key, "data":[]})
          if cursor:
             cursor.close()


    def _compute_hash(self, data):
        """Computes an MD5 hash of the data, ensuring datetime and DateTimeTZRange objects are stringified."""
        # No need for special handling here anymore as _fetch_data_by_pk now converts these types
        sorted_data = json.dumps(data, sort_keys=True).encode('utf-8')
        return hashlib.md5(sorted_data).hexdigest()
        # return hashlib.sha256(sorted_data).hexdigest()


    def _count_rows(self, key, conn, schema, table, all_results):
        cursor = conn.cursor()
        sql = f"""
            SELECT count(1) FROM ONLY {schema}.{table}
        """
        self._execute_sql(cursor, sql, conn)
        result = [row[0] for row in cursor.fetchall()]
        cursor.close()
        all_results.append({"id": key, "data":result})
        #return result

    def count_table(self, source_conn, target_conn, schema, table):
        """Count rows between source and target tables."""
        #logging.info(f"Count rows in table: {schema}.{table}")

        threads = []
        results = [] # source_rows, target_rows

        thread = threading.Thread(target=self._count_rows, args=('s',source_conn, schema, table, results))
        #source_rows = self._count_rows(source_conn, schema, table)
        threads.append(thread)
        thread.start()

        thread = threading.Thread(target=self._count_rows, args=('t',target_conn, schema, table, results))
        #target_rows = self._count_rows(target_conn, schema, table)
        threads.append(thread)
        thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        source_rows = None
        target_rows = None

        # Process results
        for result in results:
          if 'data' in result:
            if result['id'] == 's':
               source_rows=result['data']
            else:
               target_rows=result['data']

        if source_rows is None:
           logging.error(f"Problem counting rows in source for {schema}.{table}")

        if target_rows is None:
           logging.error(f"Problem counting rows in target for {schema}.{table}")

        if source_rows != target_rows:
           if schema=='public':   # we don't copy data in public schema, we will be good
              logging.warning(f"Count mismatch for {schema}.{table} - {source_rows}/{target_rows} - ignoring as we don't copy PUBLIC data")
           else:
              logging.error(f"Count mismatch for {schema}.{table} - {source_rows}/{target_rows}")

        return source_rows, target_rows


    def validate_table(self, source_conn, target_conn, schema, table, sizeb):
        """Validates data consistency between source and target tables using a sample of primary keys."""

        #logging.info(f"Validating table: {schema}.{table}")
        start_time = time.time()
        status = "Unknown"
        mismatch_print=2

        pk_columns = self._get_primary_key_columns(source_conn, schema, table)
        if not pk_columns:
            logging.warning(f"Table {schema}.{table} has no primary key. Skipping validation.")
            status = "Skipped (No Primary Key)"
            return status, time.time() - start_time

        # decide sample percentage to use, based on estimated table size, to avoid long waits in the select
        if True:   # sizeb > 10737418240:    # > 10Gb will use this
           estimated_rows = self._get_table_rows_est(source_conn, schema, table)
           # logging.info(f".... rows={estimated_rows}")
           safety_factor = Decimal(3) 
           v_sample_percentage = (Decimal(self.sample_size) / max(estimated_rows,1)) * 100 * safety_factor

           # Ensure percentage is within valid range (0.00001 to 100)
           v_sample_percentage = max(Decimal('0.00001'), min(Decimal('100.0'), v_sample_percentage))

        logging.info(f"....  getting random PKs in source (rows={estimated_rows}  sample={v_sample_percentage:.3f}%)")
        source_pks = self._get_random_primary_keys(source_conn, schema, table, pk_columns, v_sample_percentage)
        if not source_pks:
            logging.info(f"No data found in {schema}.{table} or sample size is zero.")
            status = "OK (No Data)"
            return status, time.time() - start_time

        target_pks = source_pks  # Use the same PKs to fetch from the target

        # executing SQLs in parallel threads to speed up, and also reduce the possiblity to have mismatch
        threads = []
        # Queue to collect results
        results = [] # source_data, target_data

        logging.info(f"....  Fetching data by PK in source")
        thread = threading.Thread(target=self._fetch_data_by_pk, args=('s',source_conn, schema, table, pk_columns, source_pks, results))
        # source_data = self._fetch_data_by_pk(source_conn, schema, table, pk_columns, source_pks)
        threads.append(thread)
        thread.start()

        logging.info(f"....  Fetching data by PK in target")
        thread = threading.Thread(target=self._fetch_data_by_pk, args=('t',target_conn, schema, table, pk_columns, target_pks, results))
        # target_data = self._fetch_data_by_pk(target_conn, schema, table, pk_columns, target_pks)
        threads.append(thread)
        thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        # Process results
        for result in results:
          if 'data' in result:
            if result['id'] == 's':
               source_data=result['data']
            else:
               target_data=result['data']

        # --- NEW CONDITION HERE ---
        # Check if target_data is empty (which indicates an issue like UndefinedTable)
        if not target_data:
            status = f"Skipping hash computation for {schema}.{table})."
            logging.error(f"Skipping hash computation for {schema}.{table} because target data is empty or it does not exist.")
            # You might want to return a specific status here, e.g., "SKIPPED_HASH"
            end_time = time.time()
            duration = end_time - start_time
            return status, duration

        source_data_by_pk = {}
        if len(pk_columns) == 1:
            source_data_by_pk = {row[pk_columns[0]]: row for row in source_data}
        else:
            source_data_by_pk = {tuple(row[col] for col in pk_columns): row for row in source_data}

        target_data_by_pk = {}
        if len(pk_columns) == 1:
            target_data_by_pk = {row[pk_columns[0]]: row for row in target_data}
        else:
            target_data_by_pk = {tuple(row[col] for col in pk_columns): row for row in target_data}

        mismatches = 0
        rowcnt = 0
        public_mismatch = 0

        # if len(target_data_by_pk)

        logging.info(f"....  Computing hash")
        for pk in source_pks:
            source_row = source_data_by_pk.get(pk)
            target_row = target_data_by_pk.get(pk)
            rowcnt += 1

            if source_row is None and target_row is not None:
                # print only the first 5 mismatches, to avoid flooding the output
                if mismatches < mismatch_print:
                    logging.error(f"Primary key {pk} exists in target but not in source for {schema}.{table}")
                mismatches += 1
            elif source_row is not None and target_row is None:
                if schema!='public':   # we don't copy data in public schema, we will be good
                   if mismatches < mismatch_print:
                      logging.error(f"Primary key {pk} exists in source but not in target for {schema}.{table}")
                   mismatches += 1
                else:
                   if public_mismatch <1:
                      logging.warning(f"Primary key {pk} exists in source but not in target for {schema}.{table} - Ignoring as PUBLIC data is not copied")
                   public_mismatch=1

            elif source_row is not None and target_row is not None:
                source_hash = self._compute_hash(source_row)
                target_hash = self._compute_hash(target_row)
                if source_hash != target_hash:
                    if mismatches < mismatch_print:
                        logging.error(f"Data mismatch for primary key {pk} in {schema}.{table}")
                        logging.info(f" Source data: {source_row}")
                        logging.info(f" Target data: {target_row}")
                    mismatches += 1

        end_time = time.time()
        duration = end_time - start_time

        if mismatches > 0:
            logging.warning(f"Table {schema}.{table}: Found {mismatches} data inconsistencies in the sampled data. {duration} s")
            status = f"Mismatch ({mismatches} inconsistencies in sample of {rowcnt} rows)"
        else:
            #logging.info(f"Table {schema}.{table}: Sampled data matches. {duration:.2f} sec")
            # logging.info(f"Table {schema}.{table}: Sampled data matches. {duration:.2f} sec")
            status = f"OK ({rowcnt} rows Matched)"

        return status, duration

    def run_validation(self):
        """Runs the data validation process for all tables."""

        print(f"** Validating data using HASH of {self.sample_size} rows")

        source_conn = self._connect(self.source_config)
        target_conn = self._connect(self.target_config)

        if not source_conn or not target_conn:
            return

        source_tables = self._get_tables(source_conn, v_validate_functions.v_schema_inclusion)
        target_tables = self._get_tables(target_conn, v_validate_functions.v_schema_inclusion)

        source_table_set = set(source_tables)
        target_table_set = set(target_tables)

        all_tables_to_validate = sorted(list(source_table_set.intersection(target_table_set)))
        report = {}
        overall_status = "Success"

        for schema, table in all_tables_to_validate:
            status, duration = self.validate_table(source_conn, target_conn, schema, table)
            report[(schema, table)] = {"status": status, "duration": duration}
            if "Mismatch" in status:
                overall_status = "Failed"

        # Check for tables present in one database but not the other
        source_only = sorted(list(source_table_set - target_table_set))
        target_only = sorted(list(target_table_set - source_table_set))

        print("\n------------------------")
        if source_only:
            logging.warning(f"###  Tables present only in source: {source_only}")
            for schema, table in source_only:
                report[(schema, table)] = {"status": "Source Only", "duration": 0}

        if target_only:
            logging.warning(f"### Tables present only in target: {target_only}")
            for schema, table in target_only:
                report[(schema, table)] = {"status": "Target Only", "duration": 0}

        source_conn.close()
        target_conn.close()

        print("\n------------------------")
        print("\n--- Validation Report ---")
        for (schema, table), result in report.items():
            print(f"Schema: {schema}, Table: {table} - Status: {result['status']} ({result['duration']:.2f} seconds)")

        print("\n--- Overall Validation Summary ---")
        print(f"Overall Status: {overall_status}")

    
if __name__ == "__main__":
    # Configure your source and target database connection details
    source_config = {
        'host': 'db-galactica.prod.porch.com',
        'port': 5432,
        'database': 'pro_match',
        'user': 'app_replica',
        'password': 'Fitu3Clanv1Yika3r'
    }

    target_config = {
        'host': '10.180.0.14',
        'port': 5432,
        'database': 'pro_match',
        'user': 'app_replica',
        'password': 'Fitu3Clanv1Yika3r'
    }

    # Optional: Specify schemas to exclude
    excluded_schemas = ['pglogical', 'audit', 'temp_work', 'common', 'db_build', 'pg_catalog', 'information_schema', 'pg_toast', 'pg_temp_1', 'pg_xlog']

    # Optional: Specify the number of primary keys to sample per table
    sample_size = 500

    # Enable debug mode to see executed SQL queries
    debug_mode = True

    validator = DataValidator(source_config, target_config, excluded_schemas, sample_size, debug=debug_mode)
    validator.run_validation()

