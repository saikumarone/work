 select extname::text as extension_detail from pg_extension;
