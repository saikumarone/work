SELECT table_schema||'.'||table_name as table 
FROM information_schema.tables 
WHERE table_schema IN (:include_schemas)
  AND not (table_schema='public' and table_name='pg_stat_statements_info')
ORDER BY 1;
