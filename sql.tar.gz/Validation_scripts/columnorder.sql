SELECT table_schema||'.'||table_name ||'.'||to_char(row_number() over (partition by table_schema,table_name order by ordinal_position),'000')||'.'||column_name as column
FROM  INFORMATION_SCHEMA.Columns 
WHERE table_schema IN (:include_schemas)
  AND not (table_schema='public' and table_name='pg_stat_statements_info')
ORDER BY 1;
