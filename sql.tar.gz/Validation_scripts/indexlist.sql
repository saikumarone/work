SELECT schemaname||'.'||tablename||'.'||indexname as index
FROM pg_indexes 
WHERE schemaname IN (:include_schemas)
ORDER BY 1;
